# A/L Study Buddy – build, test, publish

Kotlin, no AndroidX, no Compose. Only dependency: Google Play Billing. Not compiled yet: open it in Android Studio and fix any version prompts.

## 0. One-time setup
1. Install Android Studio (latest stable). Open this folder (File > Open).
2. If Studio offers "Upgrade Android Gradle Plugin" or asks for a newer SDK, accept. Install SDK Platform 36 if asked.
3. The Gradle wrapper jar is not included. Studio builds fine without it. For command line, run once: `gradle wrapper --gradle-version 8.11.1`.
4. Change `applicationId` and `namespace` in `app/build.gradle.kts` (and the `lk.alstudy.buddy` package folders) to your own unique ID before first upload.

## 1. Build an APK (for testing)
Studio: Build > Build Bundle(s)/APK(s) > Build APK(s). File: `app/build/outputs/apk/debug/app-debug.apk`.
Terminal: `./gradlew assembleDebug`

## 2. Test on a physical phone
1. Phone: Settings > About phone > tap Build number 7 times. Then Developer options > USB debugging ON.
2. Plug in by USB, accept the prompt. In Studio pick the phone and press Run. Or copy the APK and install it.
3. Check: profile saved, 1-minute study session (pause/resume/end), close app mid-session and reopen, reminder 2 minutes ahead, language switch, dark mode, restart phone, airplane mode (everything except AI/billing must work).
4. Usage access: Settings tab > Allow usage access > enable the app. Run a session, open another app, end the session: you see the other-apps minutes.
5. Low-end test: use an old phone, or an emulator with 2 GB RAM and API 21-23 images.

## 3. Signing key and AAB (for Google Play)
```
keytool -genkeypair -v -keystore release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload
```
Copy `keystore.properties.example` to `keystore.properties`, fill in the values. BACK UP release.jks AND PASSWORDS. Never commit them (.gitignore covers it). Use Play App Signing when asked in Play Console.
Build: Build > Generate Signed Bundle / APK > Android App Bundle, or `./gradlew bundleRelease`.
File: `app/build/outputs/bundle/release/app-release.aab`. Raise `versionCode` for every upload.

## 4. AI backend (keeps the secret key off the phone)
1. `cd backend`, create a free Cloudflare account, `npx wrangler secret put ANTHROPIC_API_KEY`, then `npx wrangler deploy worker.js --name alstudy-ai`.
2. Put the worker URL in `AI_URL` in `app/build.gradle.kts`. Before launch add a rate limit and Play Integrity checking, or anyone who finds the URL can spend your credit.
Until `AI_URL` is set, the AI button shows "not available" and nothing else is affected.

## 5. Google Play Console
1. Create developer account (one-time US$25). Create app: default language English, free app.
2. Host the privacy policy (edit `PRIVACY_POLICY_TEMPLATE.md`, e.g. on GitHub Pages). Put the URL in `PRIVACY_URL` and in Play Console.
3. Monetize > Subscriptions: create product ID `premium_monthly`, base plan monthly, price Rs. 100 (LKR). Activate. (Billing only works for builds uploaded to a Play testing track.)
4. App content: Data safety form (local data; AI sends study minutes/subjects; Billing by Google), Target audience (use 13+ or 16+; if students are under 18 read Families/Children policy), Ads: none.
5. Permissions: `PACKAGE_USAGE_STATS` may need a declaration. Explain it is optional, shows the student their own focus summary, on-device only. If review is a problem, delete that permission, `Usage.kt` and the settings block; the app still works.
6. Testing: upload AAB to Internal testing, add tester emails (add them as license testers to test purchases free), install via Play link, test purchase + restore. New personal accounts must run Closed testing with the required number of testers for the required days before Production: check current rules in Play Console.
7. Store listing: 512x512 icon, 1024x500 feature graphic, 2+ phone screenshots, short and full description in English and Sinhala (Add translation). Then Production > Create release > upload AAB > submit.

## Design notes (why it is light)
- No services. Timer is end-timestamp based; UI timer only runs while the screen is open. AlarmManager notifies when closed.
- Reminders use inexact alarms (no exact-alarm permission), so they may fire a few minutes late in Doze.
- Usage check is a single query at session end. No polling.
- SQLite with one small table; settings in SharedPreferences.
- Trial = 7 days from first launch, stored on device (and in Android backup). A determined user can reset it by clearing data without backup. For stricter control, switch to a Play-managed free-trial offer on the subscription and remove the local trial.
- Subscription state = Google Play purchase list, cached 7 days offline. Hardening: send `purchaseToken` to a backend and verify with the Google Play Developer API + Real-time developer notifications.
- Not shipped: account sync (not needed; keeps privacy simple).

## Known limits
- Sinhala needs a Sinhala system font; most Android 5+ phones in Sri Lanka have it, some very old ones show boxes.
- Billing Library and target API requirements change yearly: check the current version and target API in the Play Console before upload.
