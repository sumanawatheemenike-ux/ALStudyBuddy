# Billing library ships its own consumer rules. Nothing extra needed for this app.
-keepattributes SourceFile,LineNumberTable
