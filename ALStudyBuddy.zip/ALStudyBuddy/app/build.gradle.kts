import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val ksFile = rootProject.file("keystore.properties")
val ks = Properties().apply { if (ksFile.exists()) ksFile.inputStream().use { load(it) } }

android {
    namespace = "lk.alstudy.buddy"
    compileSdk = 36

    defaultConfig {
        applicationId = "lk.alstudy.buddy"      // CHANGE to your own unique ID before first upload
        minSdk = 21                              // Android 5.0+ (covers old budget phones)
        targetSdk = 36                           // Play requires a recent target; check current requirement
        versionCode = 1                          // +1 for every Play upload
        versionName = "1.0.0"
        androidResources { localeFilters += listOf("en", "si") }   // drops unused library languages
        // AI goes through YOUR backend (see backend/worker.js). No secret key lives in the app.
        buildConfigField("String", "AI_URL", "\"https://YOUR-WORKER.workers.dev/ai\"")
        buildConfigField("String", "PRIVACY_URL", "\"https://YOUR-SITE/privacy\"")
        buildConfigField("String", "SUB_ID", "\"premium_monthly\"")   // Play Console subscription product ID
    }

    signingConfigs {
        create("release") {
            if (ksFile.exists()) {
                storeFile = rootProject.file(ks["storeFile"] as String)
                storePassword = ks["storePassword"] as String
                keyAlias = ks["keyAlias"] as String
                keyPassword = ks["keyPassword"] as String
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            if (ksFile.exists()) signingConfig = signingConfigs.getByName("release")
        }
    }
    buildFeatures { buildConfig = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    bundle { language { enableSplit = false } }   // keep both languages in every install
}

dependencies {
    implementation("com.android.billingclient:billing:8.0.0")  // only dependency; use newest 8.x+ per Play policy
}
