package lk.alstudy.buddy

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Build
import android.os.Process

/**
 * Optional. One query when a session ends, no polling, no background service.
 * Reads only package names + foreground timestamps stored by Android itself.
 * Returns null when permission is missing or Android refuses, and the app simply skips the message.
 */
object Usage {
    fun granted(c: Context): Boolean = try {
        val a = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29)
            a.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        else @Suppress("DEPRECATION") a.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        mode == AppOpsManager.MODE_ALLOWED
    } catch (e: Exception) { false }

    /** Milliseconds other apps (not this one) were in the foreground between [from] and [to]. */
    fun otherAppsMs(c: Context, from: Long, to: Long): Long? {
        if (!granted(c)) return null
        return try {
            val u = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val ev = u.queryEvents(from, to)
            val e = UsageEvents.Event()
            val since = HashMap<String, Long>()
            var total = 0L
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                val pk = e.packageName ?: continue
                when (e.eventType) {
                    1 -> since[pk] = e.timeStamp                                   // moved to foreground
                    2 -> since.remove(pk)?.let { if (pk != c.packageName) total += e.timeStamp - it } // to background
                }
            }
            total
        } catch (e: Exception) { null }
    }
}
