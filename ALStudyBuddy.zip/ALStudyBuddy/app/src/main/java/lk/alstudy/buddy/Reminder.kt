package lk.alstudy.buddy

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

/** Uses AlarmManager (no always-running service). Time may drift a few minutes on Doze: that is by design for battery. */
object Reminder {
    private fun pi(c: Context, kind: Int): PendingIntent = PendingIntent.getBroadcast(
        c, kind, Intent(c, AlarmReceiver::class.java).putExtra("k", kind),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun set(c: Context, at: Long, kind: Int) {
        try {
            val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(c, kind))
            else am.set(AlarmManager.RTC_WAKEUP, at, pi(c, kind))
        } catch (e: Exception) { /* never crash because an alarm failed */ }
    }

    fun cancel(c: Context, kind: Int) {
        try { (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi(c, kind)) } catch (e: Exception) {}
    }

    /** kind 1 = daily reminder */
    fun daily(c: Context) {
        val p = Prefs(c)
        cancel(c, 1)
        if (!p.remOn) return
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, p.remH); set(Calendar.MINUTE, p.remM); set(Calendar.SECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        set(c, cal.timeInMillis, 1)
    }

    /** kind 2 = "session finished" while the app is closed */
    fun sessionEnd(c: Context, at: Long) = set(c, at, 2)

    fun notify(c: Context, id: Int, title: String, text: String) {
        try {
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26)
                nm.createNotificationChannel(NotificationChannel("study", c.getString(R.string.app_name), NotificationManager.IMPORTANCE_DEFAULT))
            val open = PendingIntent.getActivity(
                c, 0, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            @Suppress("DEPRECATION")
            val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, "study") else Notification.Builder(c)
            nm.notify(id, b.setSmallIcon(R.drawable.ic_stat).setContentTitle(title).setContentText(text)
                .setContentIntent(open).setAutoCancel(true).build())
        } catch (e: Exception) { /* notifications denied / blocked: ignore */ }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val lc = localized(c)
        val p = Prefs(c)
        when (i.getIntExtra("k", 0)) {
            1 -> {
                val text = if (p.remSubj.isBlank()) lc.getString(R.string.rem_text_generic)
                           else lc.getString(R.string.rem_text, p.remSubj)
                Reminder.notify(lc, 1, lc.getString(R.string.app_name), text)
                Reminder.daily(c)   // schedule tomorrow
            }
            2 -> if (p.sState == 1) Reminder.notify(lc, 2, lc.getString(R.string.app_name), lc.getString(R.string.done_title))
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Intent.ACTION_BOOT_COMPLETED) return
        Reminder.daily(c)
        val p = Prefs(c)
        if (p.sState == 1 && p.sEnd > System.currentTimeMillis()) Reminder.sessionEnd(c, p.sEnd)
    }
}
