package lk.alstudy.buddy

import android.content.Context
import android.content.res.Configuration
import java.util.Locale
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

/** All small settings + current-session state live in one SharedPreferences file. */
class Prefs(c: Context) {
    private val sp = (c.applicationContext ?: c).getSharedPreferences("p", Context.MODE_PRIVATE)

    private fun str(k: String, d: String = "") = object : ReadWriteProperty<Any?, String> {
        override fun getValue(t: Any?, p: KProperty<*>) = sp.getString(k, d) ?: d
        override fun setValue(t: Any?, p: KProperty<*>, v: String) { sp.edit().putString(k, v).apply() }
    }
    private fun lng(k: String, d: Long = 0L) = object : ReadWriteProperty<Any?, Long> {
        override fun getValue(t: Any?, p: KProperty<*>) = sp.getLong(k, d)
        override fun setValue(t: Any?, p: KProperty<*>, v: Long) { sp.edit().putLong(k, v).apply() }
    }
    private fun int(k: String, d: Int = 0) = object : ReadWriteProperty<Any?, Int> {
        override fun getValue(t: Any?, p: KProperty<*>) = sp.getInt(k, d)
        override fun setValue(t: Any?, p: KProperty<*>, v: Int) { sp.edit().putInt(k, v).apply() }
    }
    private fun bool(k: String, d: Boolean = false) = object : ReadWriteProperty<Any?, Boolean> {
        override fun getValue(t: Any?, p: KProperty<*>) = sp.getBoolean(k, d)
        override fun setValue(t: Any?, p: KProperty<*>, v: Boolean) { sp.edit().putBoolean(k, v).apply() }
    }

    // Profile
    var name by str("name")
    var stream by int("stream")
    var subjects by str("subjects")          // comma separated
    var goal by int("goal", 120)             // daily goal, minutes
    // Preferences
    var lang by str("lang", "en")            // "en" | "si"
    var theme by int("theme")                // 0 system, 1 light, 2 dark
    var usageOn by bool("usageOn")
    // Reminder
    var remOn by bool("remOn")
    var remH by int("remH", 19)
    var remM by int("remM", 0)
    var remSubj by str("remSubj")
    // Trial / subscription (cache of Google Play's answer)
    var first by lng("first")                // first launch time
    var seen by lng("seen")                  // latest clock value seen (basic clock-rollback guard)
    var subActive by bool("subActive")
    var subAt by lng("subAt")                // when Play last confirmed
    var subRenew by bool("subRenew", true)
    // Active session (0 none, 1 running, 2 paused)
    var sState by int("sState")
    var sSubj by str("sSubj")
    var sTotal by lng("sTotal")
    var sStart by lng("sStart")
    var sEnd by lng("sEnd")
    var sRem by lng("sRem")
}

/** Context that uses the language chosen inside the app (no AppCompat needed). */
fun localized(c: Context): Context {
    val cfg = Configuration(c.resources.configuration)
    cfg.setLocale(Locale(Prefs(c).lang))
    return c.createConfigurationContext(cfg)
}
