package lk.alstudy.buddy

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Plain HttpURLConnection, no networking library. Talks to YOUR backend, never to an AI provider directly. */
object Ai {
    fun ask(url: String, body: String, cb: (String?) -> Unit) {
        if (url.contains("YOUR-")) { cb(null); return }   // backend not configured yet
        Thread {
            var result: String? = null
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 20000
                c.requestMethod = "POST"; c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toByteArray()) }
                if (c.responseCode == 200) {
                    val t = JSONObject(c.inputStream.bufferedReader().readText()).optString("text", "")
                    if (t.isNotBlank()) result = t
                }
                c.disconnect()
            } catch (e: Exception) { result = null }
            cb(result)
        }.start()
    }
}
