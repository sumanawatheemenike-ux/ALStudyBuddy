package lk.alstudy.buddy

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * Single Activity, 4 tabs built in code. Screens are rebuilt on tab change (cheap) so there are no
 * fragments, adapters or view-model layers to cost memory on 2 GB phones.
 */
class MainActivity : Activity() {
    private lateinit var p: Prefs
    private lateinit var db: Db
    private lateinit var bill: Billing
    private lateinit var body: FrameLayout
    private lateinit var nav: LinearLayout
    private var tab = 0
    private var timer: CountDownTimer? = null
    private var timeTv: TextView? = null
    private val day = 86400000L
    private val accent = Color.parseColor("#3949AB")

    override fun attachBaseContext(b: Context) = super.attachBaseContext(localized(b))

    override fun onCreate(b: Bundle?) {
        p = Prefs(this)
        val night = when (p.theme) {
            1 -> false
            2 -> true
            else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        }
        setTheme(if (night) R.style.AppDark else R.style.AppLight)
        super.onCreate(b)
        db = Db(this)
        bill = Billing(this) { show() }
        bill.start()

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body = FrameLayout(this)
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        nav = LinearLayout(this)
        val labels = listOf("🏠\n" + getString(R.string.nav_home), "⏱\n" + getString(R.string.nav_study),
            "📊\n" + getString(R.string.nav_progress), "⚙\n" + getString(R.string.nav_settings))
        labels.forEachIndexed { i, l ->
            nav.addView(TextView(this).apply {
                text = l; gravity = Gravity.CENTER; textSize = 12f
                setPadding(0, dp(10), 0, dp(10))
                setOnClickListener { tab = i; show() }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
        // Android 15+ draws edge-to-edge: keep content clear of system bars.
        @Suppress("DEPRECATION")
        root.setOnApplyWindowInsetsListener { v, ins ->
            v.setPadding(ins.systemWindowInsetLeft, ins.systemWindowInsetTop, ins.systemWindowInsetRight, ins.systemWindowInsetBottom)
            ins
        }
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        val now = System.currentTimeMillis()
        if (p.first == 0L) p.first = now
        if (now > p.seen) p.seen = now
        show()
    }

    override fun onPause() { super.onPause(); timer?.cancel() }
    override fun onDestroy() { super.onDestroy(); bill.end(); db.close() }

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun str(id: Int) = getString(id)
    private fun toast(id: Int) = Toast.makeText(this, id, Toast.LENGTH_LONG).show()
    private fun themeColor(attr: Int): Int {
        val ta = obtainStyledAttributes(intArrayOf(attr)); val c = ta.getColor(0, Color.GRAY); ta.recycle(); return c
    }
    private fun LinearLayout.add(v: View, top: Int = 0) =
        addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) })
    private fun tv(t: CharSequence, size: Float = 16f, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; setTextColor(Color.WHITE); setBackgroundColor(accent); setOnClickListener { f() }
    }
    private fun row(vararg v: View) = LinearLayout(this).apply { v.forEach { addView(it, LinearLayout.LayoutParams(0, -2, 1f)) } }
    private fun edit(hint: String, t: String, num: Boolean = false) = EditText(this).apply {
        this.hint = hint; setText(t); setSingleLine()
        if (num) inputType = InputType.TYPE_CLASS_NUMBER
    }
    private fun spin(items: List<String>, sel: Int, on: (Int) -> Unit) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
        setSelection(sel)
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) { on(pos) }
            override fun onNothingSelected(a: AdapterView<*>?) {}
        }
    }
    private fun sw(t: String, on: Boolean, f: (Boolean) -> Unit) = Switch(this).apply {
        text = t; isChecked = on; setOnCheckedChangeListener { _, c -> f(c) }
    }
    private fun fmt(ms: Long): String {
        val m = (ms / 60000).toInt(); val h = m / 60
        return if (h > 0) "$h${str(R.string.unit_h)} ${m % 60}${str(R.string.unit_m)}" else "$m${str(R.string.unit_m)}"
    }
    private fun clock(ms: Long): String {
        val s = (ms + 999) / 1000; val h = s / 3600; val m = (s % 3600) / 60; val x = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, x) else String.format(Locale.US, "%02d:%02d", m, x)
    }
    private fun subjects() = p.subjects.split(",").map { it.trim() }.filter { it.isNotEmpty() }
    private fun streak(): Int {
        val days = db.doneDays().toHashSet()
        val c = Calendar.getInstance()
        if (dayKey(c.timeInMillis) !in days) c.add(Calendar.DAY_OF_YEAR, -1)
        var n = 0
        while (dayKey(c.timeInMillis) in days) { n++; c.add(Calendar.DAY_OF_YEAR, -1) }
        return n
    }
    private fun trialLeft() = maxOf(0, 7 - ((p.seen - p.first) / day).toInt())
    private fun allowed() = bill.active() || trialLeft() > 0
    private fun rem(): Long = when (p.sState) {
        1 -> maxOf(0L, p.sEnd - System.currentTimeMillis())
        2 -> p.sRem
        else -> 0L
    }

    // ---------- session logic ----------
    private fun startSession(subj: String, min: Int) {
        val now = System.currentTimeMillis(); val tot = min * 60000L
        p.sSubj = subj; p.sTotal = tot; p.sStart = now; p.sEnd = now + tot; p.sRem = tot; p.sState = 1
        Reminder.sessionEnd(this, p.sEnd); show()
    }
    private fun pauseSession() { p.sRem = rem(); p.sState = 2; Reminder.cancel(this, 2); show() }
    private fun resumeSession() {
        p.sEnd = System.currentTimeMillis() + p.sRem; p.sState = 1; Reminder.sessionEnd(this, p.sEnd); show()
    }
    private fun endSession(done: Boolean) {
        val studied = if (done) p.sTotal else p.sTotal - rem()
        val to = if (done) p.sEnd else System.currentTimeMillis()
        val subj = p.sSubj; val from = p.sStart
        Reminder.cancel(this, 2)
        p.sState = 0
        if (studied >= 60000) db.add(subj, studied, done, to)
        var msg = (if (done) str(R.string.done_title) + "\n" else "") + subj + "  " + fmt(studied)
        if (p.usageOn) Usage.otherAppsMs(this, from, to)?.let { msg += "\n" + getString(R.string.usage_result, (it / 60000).toInt()) }
        AlertDialog.Builder(this).setMessage(msg).setPositiveButton(R.string.ok, null).show()
    }

    // ---------- screens ----------
    private fun show() {
        timer?.cancel(); timeTv = null
        if (p.sState == 1 && rem() <= 0) endSession(true)
        val sec = themeColor(android.R.attr.textColorSecondary)
        for (i in 0 until nav.childCount) (nav.getChildAt(i) as TextView).apply {
            setTextColor(if (i == tab) accent else sec)
            setTypeface(null, if (i == tab) Typeface.BOLD else Typeface.NORMAL)
        }
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(20), dp(20), dp(20)) }
        when (tab) { 0 -> home(c); 1 -> study(c); 2 -> progress(c); else -> settings(c) }
        body.removeAllViews()
        body.addView(ScrollView(this).apply { addView(c) })
    }

    private fun home(c: LinearLayout) {
        val hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val g = if (hr < 12) R.string.greet_morning else if (hr < 17) R.string.greet_afternoon else R.string.greet_evening
        c.add(tv(getString(g, p.name.ifBlank { str(R.string.student) }), 24f, true))
        val d = dayKey(); val today = db.dayTotal(d)
        c.add(tv(str(R.string.today_study), 14f), 24)
        c.add(tv(fmt(today), 40f, true))
        c.add(tv(getString(R.string.streak, streak()), 20f, true), 12)
        if (p.goal > 0) c.add(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = p.goal; progress = minOf(p.goal.toLong(), today / 60000).toInt()
        }, 8)
        c.add(btn(str(R.string.start_study)) { tab = 1; show() }, 16)
        c.add(tv(str(R.string.today_sessions), 18f, true), 24)
        val list = db.sessions(d)
        if (list.isEmpty()) c.add(tv(str(R.string.no_sessions)), 4)
        list.forEach { c.add(tv("${it.first}   ${fmt(it.second)}"), 4) }
        c.add(btn(str(R.string.ai_title)) { aiMenu() }, 24)
        c.add(tv(str(R.string.ai_note), 12f), 4)
    }

    private fun study(c: LinearLayout) {
        if (p.sState == 0) {
            if (!allowed()) {
                c.add(tv(str(R.string.locked)))
                c.add(btn(str(R.string.subscribe) + " – " + str(R.string.sub_price)) { bill.buy() }, 16)
                return
            }
            val subs = subjects()
            if (subs.isEmpty()) { c.add(tv(str(R.string.add_subjects))); return }
            val durs = intArrayOf(15, 25, 45, 60, 90, 120)
            var si = 0; var di = 2
            c.add(tv(str(R.string.subject), 14f))
            c.add(spin(subs, 0) { si = it })
            c.add(tv(str(R.string.duration), 14f), 16)
            c.add(spin(durs.map { getString(R.string.minutes, it) }, 2) { di = it })
            c.add(btn(str(R.string.start_study)) { startSession(subs[si], durs[di]) }, 24)
            c.add(tv(str(R.string.today_study) + ": " + fmt(db.dayTotal(dayKey()))), 24)
        } else {
            c.add(tv(p.sSubj, 22f, true))
            val t = tv("", 56f, true).apply { gravity = Gravity.CENTER }
            timeTv = t; t.text = clock(rem())
            c.add(t, 16)
            c.add(tv(str(R.string.today_study) + ": " + fmt(db.dayTotal(dayKey()))), 8)
            if (p.sState == 1) {
                c.add(btn(str(R.string.pause)) { pauseSession() }, 24)
                timer = object : CountDownTimer(rem(), 1000) {
                    override fun onTick(l: Long) { timeTv?.text = clock(rem()) }
                    override fun onFinish() { endSession(true); show() }
                }.start()
            } else c.add(btn(str(R.string.resume)) { resumeSession() }, 24)
            c.add(btn(str(R.string.end_session)) {
                AlertDialog.Builder(this).setMessage(R.string.confirm_end)
                    .setPositiveButton(R.string.ok) { _, _ -> endSession(false); show() }
                    .setNegativeButton(R.string.cancel, null).show()
            }, 8)
        }
    }

    private fun progress(c: LinearLayout) {
        val d = dayKey()
        c.add(tv(str(R.string.today_study), 14f))
        c.add(tv(fmt(db.dayTotal(d)), 36f, true))
        c.add(tv(getString(R.string.sessions_done, db.doneCount(d))), 4)
        c.add(tv(getString(R.string.streak, streak()), 20f, true), 12)
        c.add(tv(str(R.string.by_subject), 18f, true), 20)
        db.bySubject(d).forEach { c.add(tv("${it.first}   ${fmt(it.second)}"), 4) }
        c.add(tv(str(R.string.last7), 18f, true), 24)
        val cal = Calendar.getInstance(); cal.add(Calendar.DAY_OF_YEAR, -6)
        val m = db.since(dayKey(cal.timeInMillis))
        val max = m.values.maxOrNull() ?: 0L
        val f = SimpleDateFormat("EEE", Locale(p.lang))
        for (i in 0..6) {
            val ms = m[dayKey(cal.timeInMillis)] ?: 0L
            val bar = if (max > 0) "▇".repeat((ms * 10 / max).toInt()) else ""
            c.add(tv("${f.format(cal.time)}  $bar ${fmt(ms)}"), 4)
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
    }

    private fun settings(c: LinearLayout) {
        // Profile
        c.add(tv(str(R.string.profile), 20f, true))
        val nameE = edit(str(R.string.name), p.name); c.add(nameE, 8)
        var stream = p.stream
        c.add(tv(str(R.string.stream), 14f), 8)
        c.add(spin(listOf(R.string.stream_phys, R.string.stream_bio, R.string.stream_comm, R.string.stream_arts, R.string.stream_tech)
            .map { str(it) }, p.stream) { stream = it })
        val subE = edit(str(R.string.subjects_hint), p.subjects); c.add(subE, 8)
        val goalE = edit(str(R.string.goal_min), p.goal.toString(), true); c.add(goalE, 8)
        c.add(btn(str(R.string.save)) {
            p.name = nameE.text.toString().trim(); p.stream = stream
            p.subjects = subE.text.toString(); p.goal = goalE.text.toString().toIntOrNull() ?: 120
            toast(R.string.saved)
        }, 8)

        // Reminder
        c.add(tv(str(R.string.reminder), 20f, true), 28)
        c.add(sw(str(R.string.reminder), p.remOn) { on ->
            p.remOn = on
            if (on && Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            Reminder.daily(this)
        }, 8)
        c.add(btn(getString(R.string.reminder_at, String.format(Locale.US, "%02d:%02d", p.remH, p.remM))) {
            TimePickerDialog(this, { _, h, mi -> p.remH = h; p.remM = mi; Reminder.daily(this); show() }, p.remH, p.remM, false).show()
        }, 8)
        val subs = subjects()
        if (subs.isNotEmpty()) {
            c.add(tv(str(R.string.reminder_subj), 14f), 8)
            c.add(spin(subs, maxOf(0, subs.indexOf(p.remSubj))) { p.remSubj = subs[it] })
        }

        // Language + theme
        c.add(tv(str(R.string.language), 20f, true), 28)
        c.add(row(btn("English") { p.lang = "en"; recreate() }, btn("සිංහල") { p.lang = "si"; recreate() }), 8)
        c.add(tv(str(R.string.theme), 20f, true), 28)
        c.add(row(btn(str(R.string.theme_sys)) { p.theme = 0; recreate() },
            btn(str(R.string.theme_light)) { p.theme = 1; recreate() },
            btn(str(R.string.theme_dark)) { p.theme = 2; recreate() }), 8)

        // Optional usage check
        c.add(tv(str(R.string.usage_title), 20f, true), 28)
        c.add(tv(str(R.string.usage_expl), 14f), 4)
        c.add(sw(str(R.string.usage_title), p.usageOn) { p.usageOn = it }, 8)
        c.add(tv(str(if (Usage.granted(this)) R.string.usage_state_on else R.string.usage_state_off), 14f), 4)
        c.add(btn(str(R.string.usage_grant)) {
            try { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) } catch (e: Exception) {}
        }, 4)

        // Subscription
        c.add(tv(str(R.string.sub_title), 20f, true), 28)
        val status = if (bill.active()) str(R.string.sub_active)
                     else if (trialLeft() > 0) getString(R.string.trial_left, trialLeft()) else str(R.string.trial_over)
        c.add(tv(status, 16f, true), 8)
        c.add(tv(str(R.string.sub_price), 14f), 4)
        if (bill.active()) c.add(tv(str(if (p.subRenew) R.string.sub_renew else R.string.sub_ending), 14f), 4)
        else c.add(btn(str(R.string.subscribe)) { bill.buy() }, 8)
        c.add(row(btn(str(R.string.restore)) { bill.restore() }, btn(str(R.string.manage)) {
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/account/subscriptions"))) } catch (e: Exception) {}
        }), 8)

        c.add(btn(str(R.string.privacy)) {
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(BuildConfig.PRIVACY_URL))) } catch (e: Exception) {}
        }, 28)
    }

    // ---------- AI (optional, remote, never blocks the app) ----------
    private fun aiMenu() {
        if (!allowed()) { toast(R.string.locked); return }
        val items = arrayOf(R.string.ai_plan, R.string.ai_next, R.string.ai_motivate, R.string.ai_analyze).map { str(it) }.toTypedArray()
        val modes = arrayOf("plan", "next", "motivate", "analyze")
        AlertDialog.Builder(this).setTitle(R.string.ai_title)
            .setItems(items) { _, i -> askAi(modes[i]) }.show()
    }

    private fun askAi(mode: String) {
        // Privacy: no name, no contacts, no device IDs. Only study numbers.
        val cal = Calendar.getInstance(); cal.add(Calendar.DAY_OF_YEAR, -6)
        val m = db.since(dayKey(cal.timeInMillis))
        val week = JSONArray()
        for (i in 0..6) { week.put(((m[dayKey(cal.timeInMillis)] ?: 0L) / 60000).toInt()); cal.add(Calendar.DAY_OF_YEAR, 1) }
        val bySubj = JSONObject()
        db.bySubject(dayKey()).forEach { bySubj.put(it.first, (it.second / 60000).toInt()) }
        val j = JSONObject().put("lang", p.lang).put("mode", mode).put("stream", p.stream).put("goalMin", p.goal)
            .put("subjects", JSONArray(subjects())).put("streak", streak())
            .put("hour", Calendar.getInstance().get(Calendar.HOUR_OF_DAY))
            .put("last7Min", week).put("todayBySubject", bySubj)
        Toast.makeText(this, R.string.ai_wait, Toast.LENGTH_SHORT).show()
        Ai.ask(BuildConfig.AI_URL, j.toString()) { r ->
            runOnUiThread {
                if (!isFinishing)
                    AlertDialog.Builder(this).setMessage(r ?: str(R.string.ai_fail)).setPositiveButton(R.string.ok, null).show()
            }
        }
    }

    override fun onRequestPermissionsResult(rc: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(rc, perms, res)
        if (res.isNotEmpty() && res[0] != PackageManager.PERMISSION_GRANTED) toast(R.string.notif_denied)
    }
}
