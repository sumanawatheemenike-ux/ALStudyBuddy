package lk.alstudy.buddy

import android.app.Activity
import android.widget.Toast
import com.android.billingclient.api.*

/**
 * Google Play Billing only. The app never handles card data.
 * Local check = Play's own purchase list (queryPurchasesAsync), cached up to 7 days for offline use.
 * For stronger protection add server-side verification (see README, "Hardening").
 */
class Billing(private val act: Activity, private val onChange: () -> Unit) : PurchasesUpdatedListener {
    private val p = Prefs(act)
    private var client: BillingClient? = null
    private var details: ProductDetails? = null

    fun active(): Boolean = p.subActive && System.currentTimeMillis() - p.subAt < 7L * 86400000L

    fun start() {
        try {
            client = BillingClient.newBuilder(act).setListener(this)
                .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build()).build()
            client?.startConnection(object : BillingClientStateListener {
                override fun onBillingSetupFinished(r: BillingResult) {
                    if (r.responseCode == BillingClient.BillingResponseCode.OK) { restore(); loadDetails() }
                }
                override fun onBillingServiceDisconnected() {}   // reconnect happens on next restore()/buy()
            })
        } catch (e: Exception) { client = null }
    }

    fun end() { try { client?.endConnection() } catch (e: Exception) {} }

    private fun ready() = client?.isReady == true

    private fun loadDetails() {
        val prod = QueryProductDetailsParams.Product.newBuilder()
            .setProductId(BuildConfig.SUB_ID).setProductType(BillingClient.ProductType.SUBS).build()
        client?.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder().setProductList(listOf(prod)).build()) { _, res ->
            details = res.productDetailsList.firstOrNull()
        }
    }

    /** Also used by the "Restore purchases" button. */
    fun restore() {
        if (!ready()) { start(); return }
        client?.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.SUBS).build()) { r, list ->
            if (r.responseCode != BillingClient.BillingResponseCode.OK) return@queryPurchasesAsync  // keep cache
            val good = list.filter { it.purchaseState == Purchase.PurchaseState.PURCHASED && it.products.contains(BuildConfig.SUB_ID) }
            p.subActive = good.isNotEmpty()
            p.subAt = System.currentTimeMillis()
            p.subRenew = good.firstOrNull()?.isAutoRenewing ?: true
            good.filter { !it.isAcknowledged }.forEach {   // unacknowledged purchases are refunded by Google after 3 days
                client?.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(it.purchaseToken).build()) {}
            }
            act.runOnUiThread { onChange() }
        }
    }

    fun buy() {
        val d = details
        val offer = d?.subscriptionOfferDetails?.firstOrNull()
        if (!ready() || d == null || offer == null) {
            Toast.makeText(act, R.string.billing_unavail, Toast.LENGTH_LONG).show(); start(); return
        }
        val pp = BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(d).setOfferToken(offer.offerToken).build()
        client?.launchBillingFlow(act, BillingFlowParams.newBuilder().setProductDetailsParamsList(listOf(pp)).build())
    }

    override fun onPurchasesUpdated(r: BillingResult, list: MutableList<Purchase>?) {
        if (r.responseCode == BillingClient.BillingResponseCode.OK) restore()
    }
}
