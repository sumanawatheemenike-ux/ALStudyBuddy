package lk.alstudy.buddy

import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun dayKey(t: Long = System.currentTimeMillis()): String =
    SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(t))

/** One tiny table. Profile/preferences are in Prefs, so no extra tables are needed. */
class Db(c: Context) : SQLiteOpenHelper(c.applicationContext, "study.db", null, 1) {
    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE s(id INTEGER PRIMARY KEY, subj TEXT, day TEXT, ms INTEGER, done INTEGER, at INTEGER)")
        d.execSQL("CREATE INDEX i_day ON s(day)")
    }
    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {}

    fun add(subj: String, ms: Long, done: Boolean, at: Long) {
        writableDatabase.execSQL(
            "INSERT INTO s(subj,day,ms,done,at) VALUES(?,?,?,?,?)",
            arrayOf<Any?>(subj, dayKey(at), ms, if (done) 1 else 0, at)
        )
    }

    private fun <T> q(sql: String, args: Array<String>, f: (Cursor) -> T): List<T> {
        val out = ArrayList<T>()
        readableDatabase.rawQuery(sql, args).use { while (it.moveToNext()) out.add(f(it)) }
        return out
    }

    fun dayTotal(d: String): Long = q("SELECT COALESCE(SUM(ms),0) FROM s WHERE day=?", arrayOf(d)) { it.getLong(0) }[0]
    fun doneCount(d: String): Int = q("SELECT COUNT(*) FROM s WHERE day=? AND done=1", arrayOf(d)) { it.getInt(0) }[0]
    fun sessions(d: String) = q("SELECT subj,ms FROM s WHERE day=? ORDER BY at", arrayOf(d)) { it.getString(0) to it.getLong(1) }
    fun bySubject(d: String) = q("SELECT subj,SUM(ms) FROM s WHERE day=? GROUP BY subj ORDER BY 2 DESC", arrayOf(d)) { it.getString(0) to it.getLong(1) }
    fun doneDays(): List<String> = q("SELECT DISTINCT day FROM s WHERE done=1 ORDER BY day DESC LIMIT 400", arrayOf<String>()) { it.getString(0) }
    fun since(from: String): Map<String, Long> =
        q("SELECT day,SUM(ms) FROM s WHERE day>=? GROUP BY day", arrayOf(from)) { it.getString(0) to it.getLong(1) }.toMap()
}
