# Privacy Policy – A/L Study Buddy  (TEMPLATE: edit, host on a public URL, put the URL in app/build.gradle.kts and Play Console)

**What stays on your phone:** name, A/L stream, subjects, study goal, study sessions, streak, reminder and preferences. Nothing is sent to us unless described below.

**Optional AI assistant:** only when you tap an AI option, the app sends your subjects, goal, study minutes for the last 7 days and your language to our server, which asks an AI service for a reply. Your name is not sent. Do not enter personal details in subject names.

**Optional usage access:** if you enable it in Android settings, the app reads which apps were open (names and times) once when a study session ends, on your phone only, to show you a summary. It is not uploaded or stored.

**Payments:** handled entirely by Google Play. We never see your payment details.

**We do not** use the camera or microphone, read messages or contacts, record the screen or keystrokes, or show ads.

**Backup:** Android may back up app data to your own Google account if you enabled device backup.

**Delete your data:** uninstall the app or use Android Settings > Apps > Clear storage.

**Contact:** your-email@example.com        **Last updated:** YYYY-MM-DD
