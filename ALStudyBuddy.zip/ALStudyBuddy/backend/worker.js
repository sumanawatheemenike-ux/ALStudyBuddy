// Cloudflare Worker (free tier). The Anthropic API key lives ONLY here, as a secret:
//   npx wrangler secret put ANTHROPIC_API_KEY
// Deploy: npx wrangler deploy worker.js --name alstudy-ai
const TASKS = {
  plan: "Create a simple 1-week study plan using the subjects and goal.",
  next: "Suggest which subject to study right now and for how many minutes.",
  motivate: "Give a short motivational message (max 2 sentences).",
  analyze: "Briefly analyze the last 7 days and give 2 practical tips.",
};
export default {
  async fetch(req, env) {
    if (req.method !== "POST") return new Response("Not found", { status: 404 });
    let d;
    try { d = await req.json(); } catch { return new Response("{}", { status: 400 }); }
    // TODO before launch: per-IP rate limit (Cloudflare rate limiting rule) + Play Integrity token check.
    const lang = d.lang === "si" ? "Reply in simple, natural Sinhala (Unicode)." : "Reply in simple English.";
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "x-api-key": env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01", "content-type": "application/json" },
      body: JSON.stringify({
        model: "claude-haiku-4-5-20251001",
        max_tokens: 400,
        system: `You are a friendly study coach for Sri Lankan G.C.E. A/L students. ${lang} Under 120 words. No medical or personal advice.`,
        messages: [{ role: "user", content: (TASKS[d.mode] || "Give one study tip.") + "\nData: " + JSON.stringify(d).slice(0, 1500) }],
      }),
    });
    if (!r.ok) return new Response("{}", { status: 502 });
    const j = await r.json();
    return new Response(JSON.stringify({ text: j.content?.[0]?.text ?? "" }), { headers: { "content-type": "application/json" } });
  },
};
